    var form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______;
  var object_cases_Resume_Current_Task;

  if (typeof(__aObjects__) == "undefined") {
      var __aObjects__ = [];
  }

    function loadForm_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______(ajaxServer)
    {
      swSubmitValidateForm = 1;
      var i = 0;

      if (typeof(G_Form) == "undefined") {
          return alert("form.js was not loaded");
      }

      form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______=new G_Form(document.getElementById('bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______'),'bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______');
      object_cases_Resume_Current_Task = form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______;
      __aObjects__.push(object_cases_Resume_Current_Task);
      var myForm=form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRKU04yNlhabUpHbzJadw______;
      if (myForm.aElements===undefined) alert("cases_Resume_Current_Task");
      myForm.ajaxServer = ajaxServer;

        //
        
                  i = myForm.aElements.length;

                      var element = getField("TITLE2");
            
                                      }

    
