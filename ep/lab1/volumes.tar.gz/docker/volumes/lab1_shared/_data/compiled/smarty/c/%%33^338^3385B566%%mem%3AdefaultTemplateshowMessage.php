<?php /* Smarty version 2.6.18, created on 2019-10-23 19:14:49
         compiled from mem:defaultTemplateshowMessage */ ?>
  <form id="<?php echo $this->_tpl_vars['form_id']; ?>
" name="<?php echo $this->_tpl_vars['form_name']; ?>
" action="<?php echo $this->_tpl_vars['form_action']; ?>
" class="<?php echo $this->_tpl_vars['form_className']; ?>
" method="post" encType="multipart/form-data" style="margin:0px;" onsubmit="return validateForm('<?php echo $this->_tpl_vars['form_objectRequiredFields']; ?>
');">  <div class="borderForm" style="width:<?php echo $this->_tpl_vars['form_width']; ?>
; padding-left:0; padding-right:0; border-width:<?php echo $this->_tpl_vars['form_border']; ?>
;">
    <div class="boxTop"><div class="a">&nbsp;</div><div class="b">&nbsp;</div><div class="c">&nbsp;</div></div>
    <div class="content" style="height:<?php echo $this->_tpl_vars['form_height']; ?>
;" >
    <table width="99%">
      <tr>
        <td valign='top'>
          <input type="hidden" class="notValidateThisFields" name="__notValidateThisFields__" id="__notValidateThisFields__" value="<?php echo $this->_tpl_vars['form_objectRequiredFields']; ?>
" />
          <input type="hidden" name="DynaformRequiredFields" id="DynaformRequiredFields" value="<?php echo $this->_tpl_vars['form_objectRequiredFields']; ?>
" />
          <input type="hidden" name="__DynaformName__" id="__DynaformName__" value="<?php echo $this->_tpl_vars['form_name']; ?>
" />
          <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <tr>
              <td class='FormTitle' colspan="2" align=""><?php echo $this->_tpl_vars['form']['TITLE']; ?>
</td>
            </tr>
                                                <tr>
              <td class='FormLabel' width="<?php echo $this->_tpl_vars['form_labelWidth']; ?>
"><?php echo $this->_tpl_vars['MESSAGE']; ?>
</td>
              <td class='FormFieldContent' width='<?php echo $this->_tpl_vars['form_fieldContentWidth']; ?>
' ><?php echo $this->_tpl_vars['form']['MESSAGE']; ?>
</td>
            </tr>
                                  </table>
        </td>
      </tr>
    </table>
           </div>
       <div class="boxBottom"><div class="a">&nbsp;</div><div class="b">&nbsp;</div><div class="c">&nbsp;</div></div>
       </div>
                                         </form>

