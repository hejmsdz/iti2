    var form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB;
  var object_cases_Resume;

  if (typeof(__aObjects__) == "undefined") {
      var __aObjects__ = [];
  }

    function loadForm_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB(ajaxServer)
    {
      swSubmitValidateForm = 1;
      var i = 0;

      if (typeof(G_Form) == "undefined") {
          return alert("form.js was not loaded");
      }

      form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB=new G_Form(document.getElementById('bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB'),'bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB');
      object_cases_Resume = form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB;
      __aObjects__.push(object_cases_Resume);
      var myForm=form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTWWR1ZDJB;
      if (myForm.aElements===undefined) alert("cases_Resume");
      myForm.ajaxServer = ajaxServer;

        //
        
                  i = myForm.aElements.length;

                      var element = getField("TITLE1");
            
                        i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[PRO_TITLE]'],'PRO_TITLE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Process","pmLabel":"Process","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Process","pmLabel":"Process","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[TITLE]'],'TITLE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Title","pmLabel":"Case Title","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Title","pmLabel":"Case Title","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[APP_NUMBER]'],'APP_NUMBER');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Number","pmLabel":"Case Number","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Number","pmLabel":"Case Number","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[STATUS]'],'STATUS');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Status","pmLabel":"Case Status","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Status","pmLabel":"Case Status","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[APP_UID]'],'APP_UID');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Uid","pmLabel":"Case Uid","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Uid","pmLabel":"Case Uid","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[CREATOR]'],'CREATOR');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Creator","pmLabel":"Creator","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Creator","pmLabel":"Creator","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[CREATE_DATE]'],'CREATE_DATE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Create Date","pmLabel":"Create Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Create Date","pmLabel":"Create Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[UPDATE_DATE]'],'UPDATE_DATE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Last Update","pmLabel":"Last Update","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Last Update","pmLabel":"Last Update","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[DESCRIPTION]'],'DESCRIPTION');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Description","pmLabel":"Case Description","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Case Description","pmLabel":"Case Description","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                                                                                                                                                                      }

    
