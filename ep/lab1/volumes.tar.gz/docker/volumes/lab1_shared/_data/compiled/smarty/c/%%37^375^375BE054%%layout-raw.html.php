<?php /* Smarty version 2.6.18, created on 2019-10-22 18:33:35
         compiled from layout-raw.html */ ?>
<table width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%" align="center">
		<script type="text/javascript">
      <?php echo $this->_tpl_vars['header']; ?>

    </script>
		<?php 
      global $G_TEMPLATE;
      if ($G_TEMPLATE != '')
      {
        G::LoadTemplate($G_TEMPLATE);
      }
     ?>
		</td>
	</tr>
</table>