<?php /* Smarty version 2.6.18, created on 2019-10-23 19:32:23
         compiled from layout-blank.html */ ?>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="shortcut icon" href="/images/favicon.ico"   type="image/x-icon"/>
  <?php echo $this->_tpl_vars['header']; ?>

 
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#000000" vlink="#000000" alink="#999999" marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" rightmargin="0">
<table width="100%" cellspacing="0" cellpadding="0" height="100%">
	
	<tr>
		<td width="100%" valign="top">
		<?php 
      global $G_TEMPLATE;
      if ($G_TEMPLATE != '')
      {
        G::LoadTemplate($G_TEMPLATE);
      }
     ?>
		</td>
	</tr>
</table>
</body>
</html>