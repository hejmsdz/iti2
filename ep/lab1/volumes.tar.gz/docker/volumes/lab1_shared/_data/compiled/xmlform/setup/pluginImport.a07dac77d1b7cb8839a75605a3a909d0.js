    var form_cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB;
  var object_pluginImport;

  if (typeof(__aObjects__) == "undefined") {
      var __aObjects__ = [];
  }

    function loadForm_cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB(ajaxServer)
    {
      swSubmitValidateForm = 1;
      var i = 0;

      if (typeof(G_Form) == "undefined") {
          return alert("form.js was not loaded");
      }

      form_cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB=new G_Form(document.getElementById('cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB'),'cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB');
      object_pluginImport = form_cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB;
      __aObjects__.push(object_pluginImport);
      var myForm=form_cHNpazRhQ2lwSnpsMjVyYnZxS3A0YVBoWWR1ZDJB;
      if (myForm.aElements===undefined) alert("pluginImport");
      myForm.ajaxServer = ajaxServer;

        //
        
                  i = myForm.aElements.length;

                      var element = getField("TITLE1");
            
                        i = myForm.aElements.length;

                      var element = getField("MAX_FILE_SIZE");
            
                        i = myForm.aElements.length;

                      var element = getField("PLUGIN_FILENAME");
            
                        i = myForm.aElements.length;

                      var element = getField("SAVE");
            
                        i = myForm.aElements.length;

                      var element = getField("BTN_CANCEL");
            
                        i = myForm.aElements.length;

                      var element = getField("JS");
            
                                                                                                            }

    
