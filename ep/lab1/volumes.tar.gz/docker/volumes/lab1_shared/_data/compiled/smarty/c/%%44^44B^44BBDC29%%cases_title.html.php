<?php /* Smarty version 2.6.18, created on 2019-10-23 11:54:59
         compiled from /opt/pm/processmaker/workflow/engine/templates/cases/cases_title.html */ ?>
<table width="100%" align="center">
<tr class="userGroupTitle">
	<td width="100%" align="center"><?php echo $this->_tpl_vars['CASE']; ?>
 #: <?php echo $this->_tpl_vars['APP_NUMBER']; ?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->_tpl_vars['TITLE']; ?>
: <?php echo $this->_tpl_vars['APP_TITLE']; ?>
</td>
</tr>
</table>