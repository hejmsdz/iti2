    var form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___;
  var object_cases_Resume_Current_Task;

  if (typeof(__aObjects__) == "undefined") {
      var __aObjects__ = [];
  }

    function loadForm_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___(ajaxServer)
    {
      swSubmitValidateForm = 1;
      var i = 0;

      if (typeof(G_Form) == "undefined") {
          return alert("form.js was not loaded");
      }

      form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___=new G_Form(document.getElementById('bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___'),'bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___');
      object_cases_Resume_Current_Task = form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___;
      __aObjects__.push(object_cases_Resume_Current_Task);
      var myForm=form_bHNTajBhT2lsNUhqMmFUTXg1cXM1NTdTa3FhbDNxTFlvcVRQeUpMZzRHT3gzNTA___;
      if (myForm.aElements===undefined) alert("cases_Resume_Current_Task");
      myForm.ajaxServer = ajaxServer;

        //
        
                  i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[TAS_TITLE]'],'TAS_TITLE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task","pmLabel":"Task","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task","pmLabel":"Task","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[CURRENT_USER]'],'CURRENT_USER');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Current User","pmLabel":"Current User","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Current User","pmLabel":"Current User","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[DEL_DELEGATE_DATE]'],'DEL_DELEGATE_DATE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task Delegate Date","pmLabel":"Task Delegate Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task Delegate Date","pmLabel":"Task Delegate Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[DEL_INIT_DATE]'],'DEL_INIT_DATE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task Init Date","pmLabel":"Task Init Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task Init Date","pmLabel":"Task Init Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[DEL_TASK_DUE_DATE]'],'DEL_TASK_DUE_DATE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task Due Date","pmLabel":"Task Due Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Task Due Date","pmLabel":"Task Due Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                          i = myForm.aElements.length;

                      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[DEL_FINISH_DATE]'],'DEL_FINISH_DATE');
            myForm.aElements[i].setAttributes({"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Finish Date","pmLabel":"Finish Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]});
            //alert('{"size":15,"maxLength":64,"validate":"Any","mask":"","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"gridFieldType":"text","formula":"","function":"","replaceTags":0,"renderMode":"","comma_separator":".","autocomplete":"on","label":"Finish Date","pmLabel":"Finish Date","language":"en","group":0,"mode":"view","gridLabel":"","hint":"","enableHtml":false,"style":"","withoutLabel":false,"className":"","colWidth":140,"colAlign":"left","colClassName":"","titleAlign":"","align":"","showInTable":"","dataCompareField":"","dataCompareType":"=","pmtable":"","keys":"","pmconnection":"","pmfield":"","modeGrid":"","modeForGrid":"view","options":[]}');
            
                                                                                                              }

    
