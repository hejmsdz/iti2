<?php
// Processmaker configuration
  define ('DB_ADAPTER',     'mysql' );
  define ('DB_HOST',        'mysql' );
  define ('DB_NAME',        'wf_ep' );
  define ('DB_USER',        'wf_5daf4b79c8e0c' );
  define ('DB_PASS',        'qGNKUEpz6$yxvnA' );
  define ('DB_RBAC_HOST',   'mysql' );
  define ('DB_RBAC_NAME',   'wf_ep' );
  define ('DB_RBAC_USER',   'wf_5daf4b79c8e0c' );
  define ('DB_RBAC_PASS',   'qGNKUEpz6$yxvnA' );
  define ('DB_REPORT_HOST', 'mysql' );
  define ('DB_REPORT_NAME', 'wf_ep' );
  define ('DB_REPORT_USER', 'wf_5daf4b79c8e0c' );
  define ('DB_REPORT_PASS', 'qGNKUEpz6$yxvnA' );
