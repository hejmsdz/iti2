<?php
$dbAdapter    = 'mysql';
$dbHost       = 'mysql';
$dbName       = 'wf_ep';
$dbUser       = 'wf_ep';
$dbPass       = 'qGNKUEpz6$yxvnA';
$dbRbacHost   = 'mysql';
$dbRbacName   = 'wf_ep';
$dbRbacUser   = 'wf_ep';
$dbRbacPass   = 'qGNKUEpz6$yxvnA';
$dbReportHost = 'mysql';
$dbReportName = 'wf_ep';
$dbReportUser = 'wf_ep';
$dbReportPass = 'qGNKUEpz6$yxvnA';


$dsn       = sprintf("%s://%s:%s@%s/%s", $dbAdapter, $dbUser,       $dbPass,       $dbHost,       $dbName);
$dsnRbac   = sprintf("%s://%s:%s@%s/%s", $dbAdapter, $dbRbacUser,   $dbRbacPass,   $dbRbacHost,   $dbRbacName);
$dsnReport = sprintf("%s://%s:%s@%s/%s", $dbAdapter, $dbReportUser, $dbReportPass, $dbReportHost, $dbReportName);

switch ($dbAdapter) {
  case 'mysql':
    $dsn       .= '?encoding=utf8';
    $dsnRbac   .= '?encoding=utf8';
    $dsnReport .= '?encoding=utf8';
    break;
  default:
    break;
}

$pro ['datasources']['workflow']['connection'] = $dsn;
$pro ['datasources']['workflow']['adapter'] = $dbAdapter;

$pro ['datasources']['rbac']['connection'] = $dsnRbac;
$pro ['datasources']['rbac']['adapter'] = $dbAdapter;

$pro ['datasources']['rp']['connection'] = $dsnReport;
$pro ['datasources']['rp']['adapter'] = $dbAdapter;

$pro ['datasources']['dbarray']['connection'] = 'dbarray://user:pass@localhost/pm_os';
$pro ['datasources']['dbarray']['adapter']    = 'dbarray';

return $pro;