<?php
  define('PATH_DATA',         '/opt/pm/processmaker/shared/');
  define('PATH_C',            '/opt/pm/processmaker/shared/compiled/');
  define('HASH_INSTALLATION', '067Xoc1nxWHDZsNqkpibamidcJJxnWnCbshllJaYZmrHaZdnx6TQoNZpxmmRlppimm2ZmmnIa5JtnWqUmphlmJuZl2PCZpRoyKbRqKQ');
  define('SYSTEM_HASH',       '5d0a2a1b4b90d91897a9d2a5d33a437f');
